// public/script.js

document.addEventListener('DOMContentLoaded', () => {
    // 1. Get DOM Elements
    const addBookForm = document.getElementById('addBookForm');
    const bookTableBody = document.querySelector('#bookTable tbody');

    // --- Function to Fetch and Render Books ---
    async function fetchBooks() {
        try {
            const response = await fetch('/api/books');
            const books = await response.json();

            // Clear existing rows
            bookTableBody.innerHTML = '';

            // Render each book
            books.forEach(book => {
                const row = bookTableBody.insertRow();
                row.insertCell().textContent = book.id;
                row.insertCell().textContent = book.title;
                row.insertCell().textContent = book.author;
                row.insertCell().textContent = book.isbn;

                const actionCell = row.insertCell();
                const deleteButton = document.createElement('button');
                deleteButton.textContent = 'Delete';
                deleteButton.className = 'delete-btn';
                deleteButton.onclick = () => deleteBook(book.id);
                actionCell.appendChild(deleteButton);
            });
        } catch (error) {
            console.error('Error fetching books:', error);
            alert('Could not load books.');
        }
    }

    // --- Function to Add a Book ---
    addBookForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const title = document.getElementById('title').value;
        const author = document.getElementById('author').value;
        const isbn = document.getElementById('isbn').value;

        try {
            const response = await fetch('/api/books', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title, author, isbn })
            });

            if (response.ok) {
                // Success: Clear form and refresh list
                addBookForm.reset();
                fetchBooks();
            } else {
                // Error handling (e.g., ISBN already exists)
                const errorData = await response.json();
                alert('Failed to add book: ' + errorData.error);
            }
        } catch (error) {
            console.error('Error adding book:', error);
            alert('An unknown error occurred while adding the book.');
        }
    });

    // --- Function to Delete a Book ---
    async function deleteBook(id) {
        if (!confirm('Are you sure you want to delete this book?')) {
            return;
        }

        try {
            const response = await fetch(`/api/books/${id}`, {
                method: 'DELETE'
            });

            if (response.ok) {
                fetchBooks(); // Refresh the list
            } else {
                const errorData = await response.json();
                alert('Failed to delete book: ' + errorData.error);
            }
        } catch (error) {
            console.error('Error deleting book:', error);
            alert('An unknown error occurred while deleting the book.');
        }
    }

    // Load the books when the page loads
    fetchBooks();
});