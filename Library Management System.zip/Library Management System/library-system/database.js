// database.js
const db = require('better-sqlite3')('library.db');

// Create the books table if it doesn't exist
db.exec(`
    CREATE TABLE IF NOT EXISTS books (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        author TEXT NOT NULL,
        isbn TEXT UNIQUE NOT NULL
    );
`);

// Function to add a sample book (optional)
function addSampleBook() {
    try {
        const stmt = db.prepare('INSERT INTO books (title, author, isbn) VALUES (?, ?, ?)');
        stmt.run('The Great Gatsby', 'F. Scott Fitzgerald', '9780743273565');
        console.log('Sample book added.');
    } catch (e) {
        if (!e.message.includes('UNIQUE constraint failed')) {
             // Ignore if book already exists (unique constraint failed)
             console.log(e.message);
        }
    }
}

// addSampleBook(); // Uncomment this line to add a sample book on setup

module.exports = db;