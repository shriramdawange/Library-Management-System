// server.js
const express = require('express');
const db = require('./database'); // Import the initialized database
const app = express();
const PORT = 3000;

// Middleware to parse JSON bodies from POST requests
app.use(express.json());

// Serve static files (HTML, CSS, JS) from the 'public' folder
app.use(express.static('public'));

// --- API Endpoints ---

// 1. GET /api/books - Get all books
app.get('/api/books', (req, res) => {
    try {
        const books = db.prepare('SELECT * FROM books ORDER BY title').all();
        res.json(books);
    } catch (error) {
        res.status(500).json({ error: 'Failed to retrieve books.' });
    }
});

// 2. POST /api/books - Add a new book
app.post('/api/books', (req, res) => {
    const { title, author, isbn } = req.body;
    if (!title || !author || !isbn) {
        return res.status(400).json({ error: 'Missing book details.' });
    }

    try {
        const stmt = db.prepare('INSERT INTO books (title, author, isbn) VALUES (?, ?, ?)');
        const info = stmt.run(title, author, isbn);
        res.status(201).json({ id: info.lastInsertRowid, title, author, isbn });
    } catch (error) {
        if (error.message.includes('UNIQUE constraint failed')) {
            return res.status(409).json({ error: 'A book with this ISBN already exists.' });
        }
        res.status(500).json({ error: 'Failed to add book.' });
    }
});

// 3. DELETE /api/books/:id - Delete a book
app.delete('/api/books/:id', (req, res) => {
    const bookId = req.params.id;
    try {
        const stmt = db.prepare('DELETE FROM books WHERE id = ?');
        const info = stmt.run(bookId);

        if (info.changes === 0) {
            return res.status(404).json({ error: 'Book not found.' });
        }
        res.status(200).json({ message: 'Book deleted successfully.' });
    } catch (error) {
        res.status(500).json({ error: 'Failed to delete book.' });
    }
});


// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});